WindowSizer -- Window Resizing WebExtension
===========================================

A simple, customizeable window resizer

  - Define multiple custom width & height presets in options
  - Easily switch between them via toolbar menu

Inspired by the old Firefox add-on [Browsizer]

After upgrading to Firefox 57, I could no longer user Browsizer, and no suitable repalcements were available.  So I decided to learn how to write an add-on using the WebExtensions API, and here's what I made within a few hours.

[Browsizer]: https://addons.mozilla.org/en-US/firefox/addon/browsizer
